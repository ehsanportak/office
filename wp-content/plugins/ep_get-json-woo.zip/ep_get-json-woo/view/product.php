<label>اطلاعات محصول</label>
<br>
<label>نکته: نام محصولات در فایل اکسل با مقدار فیلد replace جایگزین شده است</label>
    <table border="1">  
    <tr>  
        <th >ID</th>  
        <th>Name</th>   
        <th>replace name</th>   
        <th>Price</th>   
        <th>date</th>   
    </tr>  
    <?php

use function PHPSTORM_META\type;

$conn = new mysqli('localhost', 'portalir_usr', 'mkUJN{2qz(RB');   
    mysqli_select_db($conn, 'portalir_db');   
    $conn->set_charset("utf8");
    
    $sql = mysqli_query($conn,"SELECT * FROM wp_posts INNER JOIN wp_wc_product_meta_lookup ON wp_posts.ID=wp_wc_product_meta_lookup.product_id WHERE wp_posts.post_type='product' AND wp_posts.post_status='publish'");  
    $a=1;
    while($data = mysqli_fetch_row($sql)){  
    echo '  
    <tr>   
    <td>'.$data[0].'</td>  
    <td>'.$data[5].'</td>
    <td>'.$a.'</td>  
    <td>'.$data[27].'</td>
    <td>'.$data[2].'</td>
    </tr>  
    ';
    $a++;
    }  
    ?>  
    </table> <a href="../wp-content/plugins/ep_get-json-woo/report_root/Report_product.php"> Export To Excel </a>