<br>
<label>سفارشات در انتظار پرداخت</label>
    <table border="1">  
    <tr>  
        <th>ID</th>  
        <th>date</th>
        <th>name</th>
    </tr>  
    <?php  
    
    $conn = new mysqli('localhost', 'portalir_usr', 'mkUJN{2qz(RB');   
    mysqli_select_db($conn, 'portalir_db');   
    $conn->set_charset("utf8");
    
    $sql = mysqli_query($conn,"SELECT * FROM wp_posts INNER JOIN wp_woocommerce_order_items ON wp_posts.ID= wp_woocommerce_order_items.order_id");
    while($data = mysqli_fetch_row($sql)){  
    echo '  
    <tr>  
    <td>'.$data[0].'</td>  
    <td>'.$data[2].'</td>
    <td>'.$data[24].'</td>

    </tr>  
    ';  
    }  
    ?>  
    </table> <a href="../wp-content/plugins/ep_get-json-woo/report_root/report_pending.php"> Export To Excel </a>
