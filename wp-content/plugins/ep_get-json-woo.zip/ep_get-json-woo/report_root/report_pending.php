
<?php  
  
  $conn = new mysqli('localhost', 'portalir_usr','mkUJN{2qz(RB','portalir_db');   
  $conn->set_charset("utf8");
    
  $setSql = "SELECT wp_posts.ID,wp_posts.post_date, wp_woocommerce_order_items.order_item_name FROM wp_posts INNER JOIN wp_woocommerce_order_items ON wp_posts.ID= wp_woocommerce_order_items.order_id";  
  $setRec = mysqli_query($conn, $setSql);  
    
  $columnHeader = '';  
  $columnHeader = "ID" . "\t"."Date" . "\t" . "Name" . "\t";  
    
  $setData = '';  
    
  while ($rec = mysqli_fetch_row($setRec)) {  
      $rowData = '';  
      foreach ($rec as $value) {  
          $value = '"' . $value . '"' . "\t";  
          $rowData .= $value;  
      }  
      $setData .= trim($rowData) . "\n";  
  }  
    
   
  header("Content-type: application/octet-stream");  
  header("Content-Disposition: attachment; filename=report_pending.xls");  
  header('Content-Transfer-Encoding: binary');
  header("Pragma: no-cache");  
  header("Expires: 0");  
   
  echo chr(255).chr(254).iconv("UTF-8", "UTF-16LE//IGNORE", $columnHeader . "\n" . $setData . "\n");
   
  exit();
  
  